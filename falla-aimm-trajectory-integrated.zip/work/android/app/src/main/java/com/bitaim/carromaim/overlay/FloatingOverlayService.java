package com.bitaim.carromaim.overlay;

import android.animation.ValueAnimator;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.PointF;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.bitaim.carromaim.MainActivity;
import com.bitaim.carromaim.R;
import com.bitaim.carromaim.cv.CarromAI;
import com.bitaim.carromaim.cv.Coin;
import com.bitaim.carromaim.cv.GameState;


/**
 * FloatingOverlayService — v8.4 Low-End Optimised
 *
 * Changes vs v8.3:
 *  § STABLE_FRAMES_NEEDED 10 → 6 (fires ~200 ms sooner after board settles)
 *  § STABLE_THRESH_PX 20 → 40 (CV jitter 5–20 px no longer resets counter)
 *  § dismissPopup uses named Runnable (bug-fix: no longer cancels physics posts)
 *  § Low-end flag forwarded to CarromAI.setLowEndMode()
 */
public class FloatingOverlayService extends Service {

    private static final String TAG        = "FloatingOverlayService";
    private static final String CHANNEL_ID = "aimxassist_channel";
    private static final int    NOTIF_ID   = 1001;


    public static volatile FloatingOverlayService INSTANCE;

    private WindowManager  windowManager;
    private View           floatingBtnView;
    private AimOverlayView aimOverlayView;
    private View           popupView;
    private WindowManager.LayoutParams floatingBtnParams, overlayParams, popupParams;

    private float touchStartX, touchStartY;
    private int   viewStartX,  viewStartY;
    private long  touchDownMs;

    private boolean overlayVisible = true;
    private boolean popupShowing   = false;


    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private float dp;
    private int   screenWidth;

    private final Runnable dismissPopupRunnable = this::dismissPopup;

    private float shotSensitivity = 1.0f;

    @Nullable @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        INSTANCE = this;
        dp = getResources().getDisplayMetrics().density;
        DisplayMetrics dm = getResources().getDisplayMetrics();
        screenWidth = dm.widthPixels;

        // Forward low-end flag to CarromAI
        try {
            android.app.ActivityManager am = (android.app.ActivityManager) getSystemService(ACTIVITY_SERVICE);
            if (am != null) {
                android.app.ActivityManager.MemoryInfo mi = new android.app.ActivityManager.MemoryInfo();
                am.getMemoryInfo(mi);
                CarromAI.setLowEndMode(mi.totalMem < 1536L * 1024 * 1024);
            }
        } catch (Throwable t) { /* ignore */ }

        createNotificationChannel();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE)
            startForeground(NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else
            startForeground(NOTIF_ID, buildNotification());

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        setupAimOverlay();
        setupFloatingButton();
    }

    // ── Floating button ───────────────────────────────────────────────────────

    private void setupFloatingButton() {
        floatingBtnView = LayoutInflater.from(this).inflate(R.layout.view_floating_button, null);
        floatingBtnParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        floatingBtnParams.gravity = Gravity.TOP | Gravity.START;
        floatingBtnParams.x = 16; floatingBtnParams.y = 280;

        floatingBtnView.setOnTouchListener(new View.OnTouchListener() {
            boolean wasDrag;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        touchStartX=e.getRawX(); touchStartY=e.getRawY();
                        viewStartX=floatingBtnParams.x; viewStartY=floatingBtnParams.y;
                        touchDownMs=System.currentTimeMillis(); wasDrag=false; return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx=e.getRawX()-touchStartX, dy=e.getRawY()-touchStartY;
                        if (Math.abs(dx)>8||Math.abs(dy)>8) wasDrag=true;
                        floatingBtnParams.x=(int)(viewStartX+dx);
                        floatingBtnParams.y=(int)(viewStartY+dy);
                        try{windowManager.updateViewLayout(floatingBtnView,floatingBtnParams);}catch(Exception ignored){}
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!wasDrag) { if(popupShowing)dismissPopup();else showTogglePopup(); }
                        else snapToEdge();
                        return true;
                }
                return false;
            }
        });
        windowManager.addView(floatingBtnView, floatingBtnParams);
    }

    private void snapToEdge() {
        if (floatingBtnView == null) return;
        int btnW = floatingBtnView.getWidth(); if (btnW == 0) btnW = (int)(52*dp);
        int currentX = floatingBtnParams.x;
        int targetX = (currentX + btnW/2 < screenWidth/2) ? 8 : (screenWidth - btnW - 8);
        if (currentX == targetX) return;
        ValueAnimator anim = ValueAnimator.ofInt(currentX, targetX);
        anim.setDuration(250); anim.setInterpolator(new DecelerateInterpolator(1.8f));
        anim.addUpdateListener(a -> {
            floatingBtnParams.x = (int) a.getAnimatedValue();
            try{windowManager.updateViewLayout(floatingBtnView,floatingBtnParams);}catch(Exception ignored){}
        });
        anim.start();
    }

    // ── Toggle popup ──────────────────────────────────────────────────────────

    private void showTogglePopup() {
        if (popupShowing) return;
        popupShowing = true;
        LinearLayout ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);
        ll.setBackgroundColor(0xF2111122);
        ll.setAlpha(0f);
        int pad = (int)(13*dp);
        ll.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("AIMxASSIST v8.4");
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(Color.parseColor("#FFD700"));
        title.setTextSize(14);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        title.setPadding(0, 0, 0, (int)(6*dp));
        ll.addView(title);

        addPopupBtn(ll, pad, overlayVisible ? "Lines OFF" : "Lines ON",
                overlayVisible ? 0xFFFF5555 : 0xFF22DD55,
                v -> { toggleAimOverlay(); dismissPopup(); });

        popupView = ll;
        popupParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                PixelFormat.TRANSLUCENT);
        popupParams.gravity = Gravity.TOP | Gravity.START;
        popupParams.x = floatingBtnParams.x + (int)(60*dp);
        popupParams.y = floatingBtnParams.y;
        popupView.setOnTouchListener((v, e) -> { if(e.getAction()==MotionEvent.ACTION_OUTSIDE)dismissPopup(); return false; });
        windowManager.addView(popupView, popupParams);
        ll.animate().alpha(1f).setDuration(180).start();
        mainHandler.postDelayed(dismissPopupRunnable, 6000);
    }

    private void addPopupBtn(LinearLayout parent, int pad, String text, int color, View.OnClickListener click) {
        TextView tv = new TextView(this);
        tv.setText(text); tv.setTextColor(color); tv.setTextSize(15);
        tv.setTypeface(Typeface.DEFAULT_BOLD); tv.setGravity(Gravity.CENTER_HORIZONTAL);
        tv.setPadding(pad*2, pad, pad*2, pad); tv.setOnClickListener(click);
        parent.addView(tv);
    }

    private void dismissPopup() {
        if (!popupShowing) return;
        popupShowing = false;
        mainHandler.removeCallbacks(dismissPopupRunnable);
        View pv = popupView;
        if (pv != null) {
            pv.animate().alpha(0f).setDuration(150).withEndAction(() -> {
                try{windowManager.removeView(pv);}catch(Exception ignored){}
            }).start();
        }
        popupView = null;
    }

    // ── Aim overlay ───────────────────────────────────────────────────────────

    private void setupAimOverlay() {
        aimOverlayView = new AimOverlayView(this);
        overlayParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        |WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        |WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        |WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        |WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        aimOverlayView.setVisibility(View.VISIBLE);
        windowManager.addView(aimOverlayView, overlayParams);
    }

    // ── External API ──────────────────────────────────────────────────────────

    public void setShotMode(String mode)        { if (aimOverlayView!=null) aimOverlayView.setShotMode(mode); }
    public void setMarginOffset(float dx,float dy) {}
    public void setSensitivity(float v)         { shotSensitivity = Math.max(0.3f, Math.min(3.0f, v)); }

    public void onDetectedState(GameState s) {
        if (s == null || !s.isValid()) { onDetectionLost(); return; }
        if (aimOverlayView != null) {
            aimOverlayView.setDetectedState(s);
            if (!overlayVisible) { overlayVisible=true; aimOverlayView.setVisibility(View.VISIBLE); }
        }
    }

    public void onDetectionLost() {
        if (aimOverlayView != null) aimOverlayView.clearDetectedState();
    }

    public void toggleAimOverlay() {
        overlayVisible = !overlayVisible;
        if (aimOverlayView != null) {
            aimOverlayView.setVisibility(overlayVisible?View.VISIBLE:View.GONE);
            if (!overlayVisible && aimOverlayView != null) aimOverlayView.clearDetectedState();
        }
    }

    // ── Notification ──────────────────────────────────────────────────────────

    private int overlayType() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "AIMxASSIST Aim Overlay", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Aim prediction lines overlay");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    private Notification buildNotification() {
        int piFlags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0;
        Intent stopIntent = new Intent(this, FloatingOverlayService.class); stopIntent.setAction("ACTION_STOP");
        PendingIntent stopPi = PendingIntent.getService(this, 0, stopIntent, piFlags);
        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent openPi = PendingIntent.getActivity(this, 1, openIntent, piFlags);
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("AIMxASSIST — Aim Lines Active")
                .setContentText("Aim prediction lines are running")
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentIntent(openPi)
                .addAction(0, "Stop", stopPi)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "ACTION_STOP".equals(intent.getAction())) stopSelf();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy(); INSTANCE = null;
        dismissPopup();
        try{if(floatingBtnView!=null)windowManager.removeView(floatingBtnView);}catch(Exception ignored){}
        try{if(aimOverlayView!=null)windowManager.removeView(aimOverlayView);}catch(Exception ignored){}
    }
}
